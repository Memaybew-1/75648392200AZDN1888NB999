package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.CleaningServices
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.FileManagerViewModel
import com.example.ui.ScreenDestination
import com.example.ui.screens.CategoryDetailScreen
import com.example.ui.screens.ExplorerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageViewerScreen
import com.example.ui.screens.StarredScreen
import com.example.ui.screens.StorageCleanerScreen
import com.example.ui.screens.TextEditorScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.theme.NexusFilesTheme

class MainActivity : ComponentActivity() {
    private val viewModel: FileManagerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexusFilesTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: FileManagerViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    val showBottomBar = when (currentScreen) {
        ScreenDestination.Home,
        ScreenDestination.Explorer,
        ScreenDestination.Starred,
        ScreenDestination.Trash,
        ScreenDestination.StorageAnalyzer -> true
        else -> false
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("main_bottom_nav")
                ) {
                    val isHome = currentScreen is ScreenDestination.Home
                    val isExplorer = currentScreen is ScreenDestination.Explorer
                    val isStarred = currentScreen is ScreenDestination.Starred
                    val isCleaner = currentScreen is ScreenDestination.StorageAnalyzer

                    NavigationBarItem(
                        selected = isHome,
                        onClick = { viewModel.navigateTo(ScreenDestination.Home) },
                        icon = {
                            Icon(
                                imageVector = if (isHome) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = "Home"
                            )
                        },
                        label = { Text("Home") },
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = isExplorer,
                        onClick = {
                            viewModel.openDirectory(viewModel.repository.rootDir)
                        },
                        icon = {
                            Icon(
                                imageVector = if (isExplorer) Icons.Filled.Folder else Icons.Outlined.Folder,
                                contentDescription = "Files"
                            )
                        },
                        label = { Text("Files") },
                        modifier = Modifier.testTag("nav_item_files")
                    )

                    NavigationBarItem(
                        selected = isStarred,
                        onClick = { viewModel.navigateTo(ScreenDestination.Starred) },
                        icon = {
                            Icon(
                                imageVector = if (isStarred) Icons.Filled.Star else Icons.Outlined.Star,
                                contentDescription = "Favorites"
                            )
                        },
                        label = { Text("Favorites") },
                        modifier = Modifier.testTag("nav_item_favorites")
                    )

                    NavigationBarItem(
                        selected = isCleaner,
                        onClick = { viewModel.navigateTo(ScreenDestination.StorageAnalyzer) },
                        icon = {
                            Icon(
                                imageVector = if (isCleaner) Icons.Filled.CleaningServices else Icons.Outlined.CleaningServices,
                                contentDescription = "Analyzer"
                            )
                        },
                        label = { Text("Analyzer") },
                        modifier = Modifier.testTag("nav_item_analyzer")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val dest = currentScreen) {
                is ScreenDestination.Home -> {
                    HomeScreen(viewModel = viewModel)
                }
                is ScreenDestination.Explorer -> {
                    ExplorerScreen(viewModel = viewModel)
                }
                is ScreenDestination.CategoryDetail -> {
                    CategoryDetailScreen(category = dest.category, viewModel = viewModel)
                }
                is ScreenDestination.Starred -> {
                    StarredScreen(viewModel = viewModel)
                }
                is ScreenDestination.Recents -> {
                    HomeScreen(viewModel = viewModel)
                }
                is ScreenDestination.Trash -> {
                    TrashScreen(viewModel = viewModel)
                }
                is ScreenDestination.StorageAnalyzer -> {
                    StorageCleanerScreen(viewModel = viewModel)
                }
                is ScreenDestination.TextEditor -> {
                    TextEditorScreen(file = dest.file, viewModel = viewModel)
                }
                is ScreenDestination.ImageViewer -> {
                    ImageViewerScreen(file = dest.file, viewModel = viewModel)
                }
            }
        }
    }
}

package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.local.FileTagEntity
import com.example.data.local.RecentFileEntity
import com.example.data.local.StarredFileEntity
import com.example.data.local.TrashItemEntity
import com.example.data.model.ClipboardBuffer
import com.example.data.model.ClipboardOperation
import com.example.data.model.FileCategory
import com.example.data.model.FileItem
import com.example.data.model.SortOption
import com.example.data.model.StorageStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class FileManagerRepository(private val context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val dao = database.fileMetadataDao()

    val rootDir: File by lazy {
        val ext = context.getExternalFilesDir(null)
        val root = ext ?: context.filesDir
        val mainDir = File(root, "Storage")
        if (!mainDir.exists()) {
            mainDir.mkdirs()
        }
        mainDir
    }

    val trashDir: File by lazy {
        val tDir = File(context.filesDir, ".nexus_trash")
        if (!tDir.exists()) {
            tDir.mkdirs()
        }
        tDir
    }

    suspend fun initializeSampleFilesIfEmpty() = withContext(Dispatchers.IO) {
        val marker = File(context.filesDir, ".seeded_v1")
        if (marker.exists()) return@withContext

        try {
            val docs = File(rootDir, "Documents").apply { mkdirs() }
            val projects = File(rootDir, "Projects").apply { mkdirs() }
            val notes = File(rootDir, "Notes").apply { mkdirs() }
            val downloads = File(rootDir, "Downloads").apply { mkdirs() }
            val media = File(rootDir, "Media").apply { mkdirs() }
            val archives = File(rootDir, "Archives").apply { mkdirs() }

            // Sample Documents
            File(docs, "Project_Specification.md").writeText(
                """# Nexus Files — Architecture Overview
## Features
- Deep storage analytics & clean-up tools
- Real-time Zip compression and extraction
- In-app syntax-highlighted text and code editor
- Tagging, Starred items, and Safe Trash bin
- Multi-selection and batch file manipulation

## Tech Stack
- Jetpack Compose (Material 3)
- Room Persistence Library
- Kotlin Coroutines & StateFlow
"""
            )

            File(docs, "Q4_Financial_Report.csv").writeText(
                """Quarter,Revenue,Expenses,Net Profit,Status
Q1 2026,$124000,$82000,$42000,Audited
Q2 2026,$148500,$91000,$57500,Audited
Q3 2026,$169000,$98000,$71000,Audited
Q4 2026,$210000,$112000,$98000,Projected
"""
            )

            File(docs, "Meeting_Agenda.txt").writeText(
                """Sprint 42 Kickoff Agenda:
1. Review storage analyzer benchmarks
2. Mobile UI polish and responsiveness
3. Safe-delete recycle bin tests
4. Zip archive streaming verification
"""
            )

            // Sample Projects
            File(projects, "AppConfig.json").writeText(
                """{
  "appName": "Nexus Files",
  "version": "1.0.0",
  "theme": "Midnight Cyber",
  "enableAnalytics": true,
  "maxCacheSizeMb": 512,
  "defaultView": "LIST"
}"""
            )

            File(projects, "Main.kt").writeText(
                """package com.example.demo

fun main() {
    println("Welcome to Nexus Files Engine!")
    val storageSpace = 64 * 1024 * 1024 * 1024L
    println("Initialized virtual drive capacity: ${'$'}storageSpace bytes")
}
"""
            )

            File(projects, "styles.css").writeText(
                """:root {
  --primary-color: #00D4FF;
  --bg-color: #090D16;
  --surface-color: #131B2E;
  --accent-cyan: #06B6D4;
}

body {
  font-family: system-ui, -apple-system, sans-serif;
  background-color: var(--bg-color);
  color: #F1F5F9;
}
"""
            )

            // Sample Notes
            File(notes, "Quick_Ideas.txt").writeText(
                """- Add batch rename using regex pattern
- Support biometric lock for secure private folder
- Cloud storage integration (Drive, NextCloud)
- Duplicate photo detector based on visual hash
"""
            )

            File(notes, "Todo_Checklist.md").writeText(
                """# Weekly Checklist
- [x] Configure adaptive app icon
- [x] Integrate M3 design theme
- [x] Test safe trash restore
- [ ] Add custom file color tags
"""
            )

            // Sample Downloads
            File(downloads, "Release_Notes_v1.0.txt").writeText(
                """Nexus Files v1.0 Release
- Fast file system explorer
- Category filters
- Built-in editor with live save
"""
            )

            // Sample sample archive
            val sampleZip = File(archives, "Sample_Bundle.zip")
            val sampleFilesToZip = listOf(
                File(docs, "Meeting_Agenda.txt"),
                File(notes, "Quick_Ideas.txt")
            )
            zipFilesInternal(sampleFilesToZip, sampleZip)

            // Add some starred files and tags into database
            dao.addStarred(StarredFileEntity(path = File(docs, "Project_Specification.md").absolutePath, name = "Project_Specification.md"))
            dao.addStarred(StarredFileEntity(path = File(projects, "AppConfig.json").absolutePath, name = "AppConfig.json"))

            dao.addTag(FileTagEntity(path = File(docs, "Project_Specification.md").absolutePath, tag = "Important", colorHex = "#EF4444"))
            dao.addTag(FileTagEntity(path = File(projects, "Main.kt").absolutePath, tag = "Code", colorHex = "#10B981"))
            dao.addTag(FileTagEntity(path = File(docs, "Q4_Financial_Report.csv").absolutePath, tag = "Finance", colorHex = "#F59E0B"))

            marker.createNewFile()
        } catch (_: Exception) {
            // Ignore seed error
        }
    }

    suspend fun getFiles(
        directory: File,
        sortOption: SortOption = SortOption.NAME_ASC,
        searchQuery: String = ""
    ): List<FileItem> = withContext(Dispatchers.IO) {
        if (!directory.exists() || !directory.isDirectory) return@withContext emptyList()

        val rawFiles = directory.listFiles() ?: return@withContext emptyList()
        val starredList = dao.getAllStarred().first().map { it.path }.toSet()
        val allTags = dao.getAllTags().first().groupBy { it.path }

        val items = rawFiles
            .filter { !it.name.startsWith(".nexus_trash") && !it.name.startsWith(".seeded") }
            .filter { file ->
                if (searchQuery.isBlank()) true
                else file.name.contains(searchQuery, ignoreCase = true)
            }
            .map { file ->
                createFileItem(file, starredList.contains(file.absolutePath), allTags[file.absolutePath]?.map { it.tag } ?: emptyList())
            }

        sortFileItems(items, sortOption)
    }

    suspend fun searchFilesRecursively(
        baseDir: File = rootDir,
        query: String,
        category: FileCategory? = null
    ): List<FileItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<FileItem>()
        val starredList = dao.getAllStarred().first().map { it.path }.toSet()
        val allTags = dao.getAllTags().first().groupBy { it.path }

        fun walk(dir: File) {
            val list = dir.listFiles() ?: return
            for (f in list) {
                if (f.name.startsWith(".nexus_trash") || f.name.startsWith(".seeded")) continue
                if (f.isDirectory) {
                    if (query.isBlank() || f.name.contains(query, ignoreCase = true)) {
                        if (category == null) {
                            result.add(createFileItem(f, starredList.contains(f.absolutePath), allTags[f.absolutePath]?.map { it.tag } ?: emptyList()))
                        }
                    }
                    walk(f)
                } else {
                    val matchesQuery = query.isBlank() || f.name.contains(query, ignoreCase = true)
                    val cat = FileCategory.fromExtension(f.extension)
                    val matchesCategory = category == null || cat == category
                    if (matchesQuery && matchesCategory) {
                        result.add(createFileItem(f, starredList.contains(f.absolutePath), allTags[f.absolutePath]?.map { it.tag } ?: emptyList()))
                    }
                }
            }
        }

        walk(baseDir)
        sortFileItems(result, SortOption.DATE_DESC)
    }

    suspend fun getCategoryFiles(category: FileCategory): List<FileItem> {
        return searchFilesRecursively(baseDir = rootDir, query = "", category = category)
    }

    private fun createFileItem(file: File, isStarred: Boolean, tags: List<String>): FileItem {
        val isDir = file.isDirectory
        val childCount = if (isDir) (file.listFiles()?.count { !it.name.startsWith(".") } ?: 0) else 0
        val size = if (isDir) calculateDirectorySize(file) else file.length()
        val category = if (isDir) FileCategory.OTHER else FileCategory.fromExtension(file.extension)

        return FileItem(
            path = file.absolutePath,
            name = file.name,
            extension = file.extension,
            size = size,
            lastModified = file.lastModified(),
            isDirectory = isDir,
            childCount = childCount,
            mimeType = getMimeType(file.extension),
            category = category,
            isStarred = isStarred,
            tags = tags
        )
    }

    private fun calculateDirectorySize(dir: File): Long {
        var total = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            total += if (f.isDirectory) calculateDirectorySize(f) else f.length()
        }
        return total
    }

    private fun sortFileItems(items: List<FileItem>, sortOption: SortOption): List<FileItem> {
        val (dirs, files) = items.partition { it.isDirectory }
        val sortedDirs = when (sortOption) {
            SortOption.NAME_ASC -> dirs.sortedBy { it.name.lowercase() }
            SortOption.NAME_DESC -> dirs.sortedByDescending { it.name.lowercase() }
            SortOption.DATE_DESC -> dirs.sortedByDescending { it.lastModified }
            SortOption.DATE_ASC -> dirs.sortedBy { it.lastModified }
            SortOption.SIZE_DESC -> dirs.sortedByDescending { it.size }
            SortOption.SIZE_ASC -> dirs.sortedBy { it.size }
        }
        val sortedFiles = when (sortOption) {
            SortOption.NAME_ASC -> files.sortedBy { it.name.lowercase() }
            SortOption.NAME_DESC -> files.sortedByDescending { it.name.lowercase() }
            SortOption.DATE_DESC -> files.sortedByDescending { it.lastModified }
            SortOption.DATE_ASC -> files.sortedBy { it.lastModified }
            SortOption.SIZE_DESC -> files.sortedByDescending { it.size }
            SortOption.SIZE_ASC -> files.sortedBy { it.size }
        }
        return sortedDirs + sortedFiles
    }

    suspend fun createFolder(parentDir: File, name: String): Result<File> = withContext(Dispatchers.IO) {
        try {
            val trimmed = name.trim()
            if (trimmed.isEmpty()) return@withContext Result.failure(IllegalArgumentException("Folder name cannot be empty"))
            val newDir = File(parentDir, trimmed)
            if (newDir.exists()) return@withContext Result.failure(IllegalStateException("Folder already exists"))
            if (newDir.mkdirs()) {
                Result.success(newDir)
            } else {
                Result.failure(Exception("Failed to create folder"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createFile(parentDir: File, name: String, content: String = ""): Result<File> = withContext(Dispatchers.IO) {
        try {
            val trimmed = name.trim()
            if (trimmed.isEmpty()) return@withContext Result.failure(IllegalArgumentException("File name cannot be empty"))
            val newFile = File(parentDir, trimmed)
            if (newFile.exists()) return@withContext Result.failure(IllegalStateException("File already exists"))
            newFile.writeText(content)
            recordRecentAccess(newFile)
            Result.success(newFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rename(file: File, newName: String): Result<File> = withContext(Dispatchers.IO) {
        try {
            val trimmed = newName.trim()
            if (trimmed.isEmpty()) return@withContext Result.failure(IllegalArgumentException("New name cannot be empty"))
            val target = File(file.parentFile, trimmed)
            if (target.exists()) return@withContext Result.failure(IllegalStateException("A file with this name already exists"))
            if (file.renameTo(target)) {
                // Update starred and recent references
                if (dao.isStarred(file.absolutePath)) {
                    dao.removeStarred(file.absolutePath)
                    dao.addStarred(StarredFileEntity(target.absolutePath, target.name))
                }
                Result.success(target)
            } else {
                Result.failure(Exception("Failed to rename file"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun duplicate(file: File): Result<File> = withContext(Dispatchers.IO) {
        try {
            val parent = file.parentFile ?: return@withContext Result.failure(Exception("No parent"))
            val ext = file.extension
            val baseName = if (ext.isNotEmpty()) file.nameWithoutExtension else file.name
            var counter = 1
            var candidate: File
            do {
                val newName = if (ext.isNotEmpty()) "$baseName (Copy $counter).$ext" else "$baseName (Copy $counter)"
                candidate = File(parent, newName)
                counter++
            } while (candidate.exists())

            if (file.isDirectory) {
                file.copyRecursively(candidate, overwrite = false)
            } else {
                file.copyTo(candidate, overwrite = false)
            }
            Result.success(candidate)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun copy(source: File, destinationDir: File): Result<File> = withContext(Dispatchers.IO) {
        try {
            val target = File(destinationDir, source.name)
            val finalTarget = if (target.exists()) {
                val ext = source.extension
                val base = if (ext.isNotEmpty()) source.nameWithoutExtension else source.name
                File(destinationDir, if (ext.isNotEmpty()) "$base (Copy).$ext" else "$base (Copy)")
            } else target

            if (source.isDirectory) {
                source.copyRecursively(finalTarget, overwrite = true)
            } else {
                source.copyTo(finalTarget, overwrite = true)
            }
            Result.success(finalTarget)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun move(source: File, destinationDir: File): Result<File> = withContext(Dispatchers.IO) {
        try {
            val target = File(destinationDir, source.name)
            if (source.renameTo(target)) {
                Result.success(target)
            } else {
                // Fallback copy & delete
                if (source.isDirectory) {
                    source.copyRecursively(target, overwrite = true)
                    source.deleteRecursively()
                } else {
                    source.copyTo(target, overwrite = true)
                    source.delete()
                }
                Result.success(target)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun moveToTrash(file: File): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val trashName = "${System.currentTimeMillis()}_${file.name}"
            val trashTarget = File(trashDir, trashName)
            val size = if (file.isDirectory) calculateDirectorySize(file) else file.length()
            val isDir = file.isDirectory

            val success = file.renameTo(trashTarget)
            if (success) {
                dao.addTrashItem(
                    TrashItemEntity(
                        trashPath = trashTarget.absolutePath,
                        originalPath = file.absolutePath,
                        originalName = file.name,
                        size = size,
                        isDirectory = isDir,
                        deletedAt = System.currentTimeMillis()
                    )
                )
                dao.removeStarred(file.absolutePath)
                dao.removeRecent(file.absolutePath)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to move to trash"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreFromTrash(trashItem: TrashItemEntity): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val trashFile = File(trashItem.trashPath)
            if (!trashFile.exists()) {
                dao.removeTrashItem(trashItem.trashPath)
                return@withContext Result.failure(Exception("Trash item file no longer exists"))
            }

            val targetFile = File(trashItem.originalPath)
            val targetDir = targetFile.parentFile ?: rootDir
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }

            val finalTarget = if (targetFile.exists()) {
                File(targetDir, "Restored_${targetFile.name}")
            } else targetFile

            val restored = trashFile.renameTo(finalTarget)
            if (restored) {
                dao.removeTrashItem(trashItem.trashPath)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to restore item"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePermanently(file: File): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val deleted = if (file.isDirectory) file.deleteRecursively() else file.delete()
            if (deleted) {
                dao.removeTrashItem(file.absolutePath)
                dao.removeStarred(file.absolutePath)
                dao.removeRecent(file.absolutePath)
                dao.clearTagsForFile(file.absolutePath)
                Result.success(Unit)
            } else {
                Result.failure(Exception("Failed to delete file"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun emptyTrash(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            trashDir.deleteRecursively()
            trashDir.mkdirs()
            dao.clearAllTrash()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun zipFiles(files: List<File>, destinationZip: File): Result<File> = withContext(Dispatchers.IO) {
        try {
            zipFilesInternal(files, destinationZip)
            Result.success(destinationZip)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun zipFilesInternal(files: List<File>, destinationZip: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(destinationZip))).use { out ->
            for (f in files) {
                addFileToZip("", f, out)
            }
        }
    }

    private fun addFileToZip(basePath: String, file: File, out: ZipOutputStream) {
        val entryName = if (basePath.isEmpty()) file.name else "$basePath/${file.name}"
        if (file.isDirectory) {
            val dirEntry = ZipEntry("$entryName/")
            out.putNextEntry(dirEntry)
            out.closeEntry()
            file.listFiles()?.forEach { child ->
                addFileToZip(entryName, child, out)
            }
        } else {
            val entry = ZipEntry(entryName)
            out.putNextEntry(entry)
            BufferedInputStream(FileInputStream(file)).use { origin ->
                val buffer = ByteArray(2048)
                var count: Int
                while (origin.read(buffer, 0, 2048).also { count = it } != -1) {
                    out.write(buffer, 0, count)
                }
            }
            out.closeEntry()
        }
    }

    suspend fun unzipArchive(zipFile: File, destinationDir: File): Result<List<File>> = withContext(Dispatchers.IO) {
        try {
            val extractedFiles = mutableListOf<File>()
            ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val destFile = File(destinationDir, entry.name)
                    // Guard against Zip Slip vulnerability
                    val canonicalDest = destFile.canonicalPath
                    val canonicalDestDir = destinationDir.canonicalPath
                    if (!canonicalDest.startsWith(canonicalDestDir)) {
                        entry = zis.nextEntry
                        continue
                    }

                    if (entry.isDirectory) {
                        destFile.mkdirs()
                    } else {
                        destFile.parentFile?.mkdirs()
                        FileOutputStream(destFile).use { fos ->
                            val buffer = ByteArray(2048)
                            var len: Int
                            while (zis.read(buffer).also { len = it } > 0) {
                                fos.write(buffer, 0, len)
                            }
                        }
                        extractedFiles.add(destFile)
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            Result.success(extractedFiles)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun readText(file: File): String = withContext(Dispatchers.IO) {
        if (!file.exists()) "" else file.readText()
    }

    suspend fun writeText(file: File, content: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            file.writeText(content)
            recordRecentAccess(file)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleStar(file: FileItem) = withContext(Dispatchers.IO) {
        if (file.isStarred) {
            dao.removeStarred(file.path)
        } else {
            dao.addStarred(StarredFileEntity(file.path, file.name))
        }
    }

    fun getStarredFiles(): Flow<List<StarredFileEntity>> = dao.getAllStarred()
    fun getRecentFiles(): Flow<List<RecentFileEntity>> = dao.getRecentFiles()
    fun getTrashItems(): Flow<List<TrashItemEntity>> = dao.getAllTrashItems()
    fun getAllTags(): Flow<List<FileTagEntity>> = dao.getAllTags()

    suspend fun addTag(path: String, tag: String, colorHex: String) = withContext(Dispatchers.IO) {
        dao.addTag(FileTagEntity(path, tag, colorHex))
    }

    suspend fun removeTag(path: String, tag: String) = withContext(Dispatchers.IO) {
        dao.removeTag(path, tag)
    }

    suspend fun recordRecentAccess(file: File) = withContext(Dispatchers.IO) {
        dao.recordAccess(RecentFileEntity(file.absolutePath, file.name))
    }

    suspend fun calculateStorageStats(): StorageStats = withContext(Dispatchers.IO) {
        var totalUsed = 0L
        val catBreakdown = mutableMapOf<FileCategory, Long>()
        var count = 0

        fun scan(dir: File) {
            val list = dir.listFiles() ?: return
            for (f in list) {
                if (f.name.startsWith(".nexus_trash") || f.name.startsWith(".seeded")) continue
                if (f.isDirectory) {
                    scan(f)
                } else {
                    val len = f.length()
                    totalUsed += len
                    count++
                    val cat = FileCategory.fromExtension(f.extension)
                    catBreakdown[cat] = (catBreakdown[cat] ?: 0L) + len
                }
            }
        }

        scan(rootDir)

        val totalVirtualSpace = 32L * 1024 * 1024 * 1024 // 32 GB representative device internal partition
        val freeSpace = (totalVirtualSpace - totalUsed).coerceAtLeast(0L)

        StorageStats(
            totalBytes = totalVirtualSpace,
            usedBytes = totalUsed,
            freeBytes = freeSpace,
            categoryBytes = catBreakdown,
            totalFileCount = count
        )
    }

    suspend fun findOptimizationCandidates(): OptimizationReport = withContext(Dispatchers.IO) {
        val largeFiles = mutableListOf<FileItem>()
        val emptyFolders = mutableListOf<File>()
        val duplicates = mutableListOf<List<FileItem>>()
        val sizeMap = mutableMapOf<Long, MutableList<File>>()
        val starredList = dao.getAllStarred().first().map { it.path }.toSet()
        val allTags = dao.getAllTags().first().groupBy { it.path }

        fun scan(dir: File) {
            val list = dir.listFiles() ?: return
            if (list.isEmpty()) {
                emptyFolders.add(dir)
                return
            }
            for (f in list) {
                if (f.name.startsWith(".nexus_trash") || f.name.startsWith(".seeded")) continue
                if (f.isDirectory) {
                    scan(f)
                } else {
                    val len = f.length()
                    if (len > 50 * 1024) { // Files > 50KB for demo optimization
                        largeFiles.add(createFileItem(f, starredList.contains(f.absolutePath), allTags[f.absolutePath]?.map { it.tag } ?: emptyList()))
                    }
                    if (len > 0) {
                        val existing = sizeMap.getOrPut(len) { mutableListOf() }
                        existing.add(f)
                    }
                }
            }
        }

        scan(rootDir)

        // Find duplicates by comparing hash
        for ((_, group) in sizeMap) {
            if (group.size > 1) {
                val hashMap = mutableMapOf<String, MutableList<File>>()
                for (f in group) {
                    val hash = calculateFileHash(f)
                    if (hash.isNotEmpty()) {
                        hashMap.getOrPut(hash) { mutableListOf() }.add(f)
                    }
                }
                for ((_, hashGroup) in hashMap) {
                    if (hashGroup.size > 1) {
                        duplicates.add(hashGroup.map {
                            createFileItem(it, starredList.contains(it.absolutePath), allTags[it.absolutePath]?.map { tag -> tag.tag } ?: emptyList())
                        })
                    }
                }
            }
        }

        val trashCount = (trashDir.listFiles() ?: emptyArray()).size
        var trashSize = 0L
        trashDir.listFiles()?.forEach { trashSize += it.length() }

        OptimizationReport(
            largeFiles = largeFiles.sortedByDescending { it.size },
            emptyFolders = emptyFolders,
            duplicateGroups = duplicates,
            trashFileCount = trashCount,
            trashSizeBytes = trashSize
        )
    }

    private fun calculateFileHash(file: File): String {
        return try {
            val digest = MessageDigest.getInstance("MD5")
            FileInputStream(file).use { fis ->
                val buffer = ByteArray(1024)
                var read: Int
                while (fis.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            ""
        }
    }

    private fun getMimeType(extension: String): String {
        return when (extension.lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "pdf" -> "application/pdf"
            "txt", "log" -> "text/plain"
            "md" -> "text/markdown"
            "json" -> "application/json"
            "xml" -> "application/xml"
            "csv" -> "text/csv"
            "zip" -> "application/zip"
            "kt" -> "text/x-kotlin"
            else -> "application/octet-stream"
        }
    }
}

data class OptimizationReport(
    val largeFiles: List<FileItem>,
    val emptyFolders: List<File>,
    val duplicateGroups: List<List<FileItem>>,
    val trashFileCount: Int,
    val trashSizeBytes: Long
)

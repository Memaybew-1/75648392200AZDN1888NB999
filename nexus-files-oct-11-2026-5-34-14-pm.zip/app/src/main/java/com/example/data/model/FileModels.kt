package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.CategoryArchive
import com.example.ui.theme.CategoryAudio
import com.example.ui.theme.CategoryCode
import com.example.ui.theme.CategoryDocument
import com.example.ui.theme.CategoryDownload
import com.example.ui.theme.CategoryImage
import com.example.ui.theme.CategoryOther
import com.example.ui.theme.CategoryVideo
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FileCategory(val title: String) {
    IMAGES("Images"),
    VIDEOS("Videos"),
    AUDIO("Audio"),
    DOCUMENTS("Documents"),
    ARCHIVES("Archives"),
    CODE("Code & Scripts"),
    DOWNLOADS("Downloads"),
    OTHER("Other");

    fun getIcon(): ImageVector {
        return when (this) {
            IMAGES -> Icons.Default.Image
            VIDEOS -> Icons.Default.VideoFile
            AUDIO -> Icons.Default.Audiotrack
            DOCUMENTS -> Icons.Default.Description
            ARCHIVES -> Icons.Default.Archive
            CODE -> Icons.Default.Code
            DOWNLOADS -> Icons.Default.Download
            OTHER -> Icons.AutoMirrored.Filled.InsertDriveFile
        }
    }

    fun getColor(): Color {
        return when (this) {
            IMAGES -> CategoryImage
            VIDEOS -> CategoryVideo
            AUDIO -> CategoryAudio
            DOCUMENTS -> CategoryDocument
            ARCHIVES -> CategoryArchive
            CODE -> CategoryCode
            DOWNLOADS -> CategoryDownload
            OTHER -> CategoryOther
        }
    }

    companion object {
        fun fromExtension(ext: String): FileCategory {
            val lower = ext.lowercase()
            return when (lower) {
                "jpg", "jpeg", "png", "webp", "gif", "bmp", "svg", "heic" -> IMAGES
                "mp4", "mkv", "avi", "mov", "webm", "flv", "wmv", "3gp" -> VIDEOS
                "mp3", "wav", "m4a", "flac", "ogg", "aac", "opus" -> AUDIO
                "pdf", "doc", "docx", "txt", "rtf", "odt", "xls", "xlsx", "csv", "ppt", "pptx", "md" -> DOCUMENTS
                "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "apk" -> ARCHIVES
                "kt", "java", "json", "xml", "html", "css", "js", "ts", "py", "c", "cpp", "h", "sql", "sh", "yaml", "yml" -> CODE
                else -> OTHER
            }
        }
    }
}

data class FileItem(
    val path: String,
    val name: String,
    val extension: String,
    val size: Long,
    val lastModified: Long,
    val isDirectory: Boolean,
    val childCount: Int = 0,
    val mimeType: String = "",
    val category: FileCategory = FileCategory.OTHER,
    val isStarred: Boolean = false,
    val tags: List<String> = emptyList()
) {
    val file: File
        get() = File(path)

    val formattedSize: String
        get() {
            if (isDirectory) return "$childCount items"
            return formatFileSize(size)
        }

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault())
            return sdf.format(Date(lastModified))
        }

    val isTextEditable: Boolean
        get() {
            if (isDirectory) return false
            val ext = extension.lowercase()
            return ext in listOf("txt", "md", "json", "xml", "kt", "java", "csv", "log", "html", "css", "js", "ts", "py", "sh", "sql", "yaml", "yml", "properties", "gradle", "conf", "env")
        }

    val isImage: Boolean
        get() = !isDirectory && category == FileCategory.IMAGES

    val isAudio: Boolean
        get() = !isDirectory && category == FileCategory.AUDIO

    val isArchive: Boolean
        get() = !isDirectory && (extension.equals("zip", ignoreCase = true))

    companion object {
        fun formatFileSize(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt().coerceIn(0, units.size - 1)
            val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
            return String.format(Locale.US, "%.1f %s", value, units[digitGroups])
        }
    }
}

enum class SortOption(val displayName: String) {
    NAME_ASC("Name (A to Z)"),
    NAME_DESC("Name (Z to A)"),
    DATE_DESC("Date (Newest first)"),
    DATE_ASC("Date (Oldest first)"),
    SIZE_DESC("Size (Largest first)"),
    SIZE_ASC("Size (Smallest first)")
}

enum class ViewMode {
    LIST,
    GRID
}

data class StorageStats(
    val totalBytes: Long,
    val usedBytes: Long,
    val freeBytes: Long,
    val categoryBytes: Map<FileCategory, Long> = emptyMap(),
    val totalFileCount: Int = 0
) {
    val usedPercent: Float
        get() = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

enum class ClipboardOperation {
    COPY,
    MOVE
}

data class ClipboardBuffer(
    val files: List<FileItem>,
    val operation: ClipboardOperation
)

package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.FileItem
import com.example.data.model.SortOption
import com.example.data.model.ViewMode
import com.example.ui.FileManagerViewModel
import com.example.ui.components.BreadcrumbBar
import com.example.ui.components.ClipboardPasteBanner
import com.example.ui.components.CreateFileDialog
import com.example.ui.components.CreateFolderDialog
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.FileDetailsDialog
import com.example.ui.components.FileGridItem
import com.example.ui.components.FileListItem
import com.example.ui.components.MultiSelectActionBar
import com.example.ui.components.RenameDialog
import com.example.ui.components.ZipDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExplorerScreen(
    viewModel: FileManagerViewModel,
    modifier: Modifier = Modifier
) {
    val currentDir by viewModel.currentDirectory.collectAsState()
    val files by viewModel.currentFiles.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val clipboard by viewModel.clipboard.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    var isSearchVisible by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var fabMenuExpanded by remember { mutableStateOf(false) }

    // Dialog states
    var showCreateFolderDialog by remember { mutableStateOf(false) }
    var showCreateFileDialog by remember { mutableStateOf(false) }
    var renamingFile by remember { mutableStateOf<FileItem?>(null) }
    var zippingFiles by remember { mutableStateOf(false) }
    var detailsFile by remember { mutableStateOf<FileItem?>(null) }
    var deletingFile by remember { mutableStateOf<FileItem?>(null) }
    var showBatchDeleteDialog by remember { mutableStateOf(false) }

    // Back handling: if in subfolder, go up; otherwise go to previous screen
    BackHandler {
        if (selectedFiles.isNotEmpty()) {
            viewModel.clearSelection()
        } else if (!viewModel.navigateUpDirectory()) {
            viewModel.navigateBack()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("explorer_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (currentDir.absolutePath == viewModel.repository.rootDir.absolutePath) "Files" else currentDir.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${files.size} items",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (!viewModel.navigateUpDirectory()) {
                                viewModel.navigateBack()
                            }
                        },
                        modifier = Modifier.testTag("explorer_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { isSearchVisible = !isSearchVisible },
                        modifier = Modifier.testTag("toggle_search_button")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                    }

                    IconButton(
                        onClick = { viewModel.toggleViewMode() },
                        modifier = Modifier.testTag("toggle_view_mode_button")
                    ) {
                        Icon(
                            imageVector = if (viewMode == ViewMode.LIST) Icons.Default.GridView else Icons.Default.ViewList,
                            contentDescription = "Toggle View"
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { sortMenuExpanded = true },
                            modifier = Modifier.testTag("sort_menu_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Sort, contentDescription = "Sort")
                        }

                        DropdownMenu(
                            expanded = sortMenuExpanded,
                            onDismissRequest = { sortMenuExpanded = false }
                        ) {
                            SortOption.values().forEach { option ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = option.displayName,
                                            fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                            color = if (sortOption == option) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    onClick = {
                                        viewModel.setSortOption(option)
                                        sortMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AnimatedVisibility(visible = fabMenuExpanded) {
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ExtendedFloatingActionButton(
                            onClick = {
                                fabMenuExpanded = false
                                showCreateFolderDialog = true
                            },
                            icon = { Icon(Icons.Default.CreateNewFolder, contentDescription = null) },
                            text = { Text("New Folder") },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("fab_new_folder")
                        )

                        ExtendedFloatingActionButton(
                            onClick = {
                                fabMenuExpanded = false
                                showCreateFileDialog = true
                            },
                            icon = { Icon(Icons.Default.NoteAdd, contentDescription = null) },
                            text = { Text("New File") },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.testTag("fab_new_file")
                        )

                        SmallFloatingActionButton(
                            onClick = {
                                fabMenuExpanded = false
                                viewModel.refreshCurrentDirectory()
                                viewModel.refreshStorageStats()
                            },
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                        }
                    }
                }

                FloatingActionButton(
                    onClick = { fabMenuExpanded = !fabMenuExpanded },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("explorer_fab")
                ) {
                    Icon(
                        imageVector = if (fabMenuExpanded) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = "Actions"
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Search bar if toggled
                AnimatedVisibility(visible = isSearchVisible) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("Filter current directory...") },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                            .testTag("explorer_search_input")
                    )
                }

                // Breadcrumb path navigation
                BreadcrumbBar(
                    rootDir = viewModel.repository.rootDir,
                    currentDir = currentDir,
                    onNavigateToDir = { viewModel.openDirectory(it) }
                )

                // Clipboard Paste Bar
                ClipboardPasteBanner(
                    clipboard = clipboard,
                    onPaste = { viewModel.pasteClipboard() },
                    onCancel = { viewModel.clearClipboard() }
                )

                // Loading or Files content
                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else if (files.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .testTag("empty_folder_view"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Text(
                                text = if (searchQuery.isNotEmpty()) "No files match '$searchQuery'" else "This folder is empty",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Tap the + button to create a file or folder",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    val isSelectionMode = selectedFiles.isNotEmpty()

                    if (viewMode == ViewMode.LIST) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f)
                                .testTag("file_list_view"),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(files, key = { it.path }) { file ->
                                val isSelected = selectedFiles.contains(file)
                                FileListItem(
                                    file = file,
                                    isSelected = isSelected,
                                    isSelectionMode = isSelectionMode,
                                    onClick = {
                                        if (isSelectionMode) {
                                            viewModel.toggleFileSelection(file)
                                        } else {
                                            viewModel.openFile(file)
                                        }
                                    },
                                    onLongClick = {
                                        viewModel.toggleFileSelection(file)
                                    },
                                    onStarClick = { viewModel.toggleStar(file) },
                                    onRenameClick = { renamingFile = file },
                                    onDuplicateClick = { viewModel.duplicateFile(file) },
                                    onDeleteClick = { deletingFile = file },
                                    onZipClick = {
                                        viewModel.clearSelection()
                                        viewModel.toggleFileSelection(file)
                                        zippingFiles = true
                                    },
                                    onDetailsClick = { detailsFile = file }
                                )
                            }
                        }
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 135.dp),
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f)
                                .testTag("file_grid_view"),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(files, key = { it.path }) { file ->
                                val isSelected = selectedFiles.contains(file)
                                FileGridItem(
                                    file = file,
                                    isSelected = isSelected,
                                    isSelectionMode = isSelectionMode,
                                    onClick = {
                                        if (isSelectionMode) {
                                            viewModel.toggleFileSelection(file)
                                        } else {
                                            viewModel.openFile(file)
                                        }
                                    },
                                    onLongClick = {
                                        viewModel.toggleFileSelection(file)
                                    },
                                    onStarClick = { viewModel.toggleStar(file) },
                                    onRenameClick = { renamingFile = file },
                                    onDuplicateClick = { viewModel.duplicateFile(file) },
                                    onDeleteClick = { deletingFile = file },
                                    onZipClick = {
                                        viewModel.clearSelection()
                                        viewModel.toggleFileSelection(file)
                                        zippingFiles = true
                                    },
                                    onDetailsClick = { detailsFile = file }
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Multi-Select Bar
            MultiSelectActionBar(
                selectedCount = selectedFiles.size,
                onSelectAll = { viewModel.selectAllFiles() },
                onCopy = { viewModel.copySelected() },
                onCut = { viewModel.cutSelected() },
                onZip = { zippingFiles = true },
                onDelete = { showBatchDeleteDialog = true },
                onClear = { viewModel.clearSelection() },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }

    // Dialogs
    if (showCreateFolderDialog) {
        CreateFolderDialog(
            onDismiss = { showCreateFolderDialog = false },
            onConfirm = { name ->
                showCreateFolderDialog = false
                viewModel.createFolder(name)
            }
        )
    }

    if (showCreateFileDialog) {
        CreateFileDialog(
            onDismiss = { showCreateFileDialog = false },
            onConfirm = { name, content ->
                showCreateFileDialog = false
                viewModel.createFile(name, content)
            }
        )
    }

    renamingFile?.let { file ->
        RenameDialog(
            initialName = file.name,
            onDismiss = { renamingFile = null },
            onConfirm = { newName ->
                renamingFile = null
                viewModel.renameFile(file, newName)
            }
        )
    }

    if (zippingFiles) {
        val defaultZipName = if (selectedFiles.size == 1) {
            "${selectedFiles.first().file.nameWithoutExtension}.zip"
        } else "Archive.zip"

        ZipDialog(
            defaultName = defaultZipName,
            onDismiss = { zippingFiles = false },
            onConfirm = { zipName ->
                zippingFiles = false
                viewModel.zipSelectedFiles(zipName)
            }
        )
    }

    detailsFile?.let { file ->
        FileDetailsDialog(
            file = file,
            onDismiss = { detailsFile = null }
        )
    }

    deletingFile?.let { file ->
        DeleteConfirmDialog(
            itemCount = 1,
            itemName = file.name,
            onDismiss = { deletingFile = null },
            onConfirm = {
                deletingFile = null
                viewModel.deleteFileToTrash(file)
            }
        )
    }

    if (showBatchDeleteDialog) {
        DeleteConfirmDialog(
            itemCount = selectedFiles.size,
            onDismiss = { showBatchDeleteDialog = false },
            onConfirm = {
                showBatchDeleteDialog = false
                viewModel.deleteSelectedToTrash()
            }
        )
    }
}

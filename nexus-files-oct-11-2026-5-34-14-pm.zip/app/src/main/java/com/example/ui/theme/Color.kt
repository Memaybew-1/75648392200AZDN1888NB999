package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Electric & Cyan
val CyanPrimary = Color(0xFF00D4FF)
val CyanPrimaryDark = Color(0xFF0099CC)
val BlueSecondary = Color(0xFF3B82F6)
val BlueSecondaryDark = Color(0xFF2563EB)

// Surfaces & Backgrounds (Dark Mode)
val MidnightBackground = Color(0xFF090D16)
val DeepSurface = Color(0xFF131B2E)
val DeepSurfaceVariant = Color(0xFF1E293B)
val SlateOutline = Color(0xFF334155)
val SlateTextPrimary = Color(0xFFF1F5F9)
val SlateTextSecondary = Color(0xFF94A3B8)

// Surfaces & Backgrounds (Light Mode)
val LightBg = Color(0xFFF8FAFC)
val LightSurf = Color(0xFFFFFFFF)
val LightSurfVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Accent Category Colors
val CategoryImage = Color(0xFFEC4899)    // Pink/Rose
val CategoryVideo = Color(0xFFF43F5E)    // Rose/Red
val CategoryAudio = Color(0xFF8B5CF6)    // Purple
val CategoryDocument = Color(0xFF3B82F6) // Blue
val CategoryArchive = Color(0xFFF59E0B)  // Amber
val CategoryCode = Color(0xFF10B981)     // Emerald
val CategoryOther = Color(0xFF64748B)    // Slate
val CategoryDownload = Color(0xFF06B6D4) // Cyan
val WarningRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)

package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TrashItemEntity
import com.example.data.model.ClipboardBuffer
import com.example.data.model.ClipboardOperation
import com.example.data.model.FileCategory
import com.example.data.model.FileItem
import com.example.data.model.SortOption
import com.example.data.model.StorageStats
import com.example.data.model.ViewMode
import com.example.data.repository.FileManagerRepository
import com.example.data.repository.OptimizationReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File

sealed class ScreenDestination {
    object Home : ScreenDestination()
    object Explorer : ScreenDestination()
    data class CategoryDetail(val category: FileCategory) : ScreenDestination()
    object Starred : ScreenDestination()
    object Recents : ScreenDestination()
    object Trash : ScreenDestination()
    object StorageAnalyzer : ScreenDestination()
    data class TextEditor(val file: FileItem) : ScreenDestination()
    data class ImageViewer(val file: FileItem) : ScreenDestination()
}

class FileManagerViewModel(application: Application) : AndroidViewModel(application) {
    val repository = FileManagerRepository(application)

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.Home)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val screenStack = mutableListOf<ScreenDestination>()

    private val _currentDirectory = MutableStateFlow<File>(repository.rootDir)
    val currentDirectory: StateFlow<File> = _currentDirectory.asStateFlow()

    private val _currentFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val currentFiles: StateFlow<List<FileItem>> = _currentFiles.asStateFlow()

    private val _categoryFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val categoryFiles: StateFlow<List<FileItem>> = _categoryFiles.asStateFlow()

    private val _storageStats = MutableStateFlow<StorageStats>(
        StorageStats(totalBytes = 32L * 1024 * 1024 * 1024, usedBytes = 0, freeBytes = 32L * 1024 * 1024 * 1024)
    )
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.NAME_ASC)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.LIST)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFiles = MutableStateFlow<Set<FileItem>>(emptySet())
    val selectedFiles: StateFlow<Set<FileItem>> = _selectedFiles.asStateFlow()

    private val _clipboard = MutableStateFlow<ClipboardBuffer?>(null)
    val clipboard: StateFlow<ClipboardBuffer?> = _clipboard.asStateFlow()

    private val _trashItems = MutableStateFlow<List<TrashItemEntity>>(emptyList())
    val trashItems: StateFlow<List<TrashItemEntity>> = _trashItems.asStateFlow()

    private val _starredFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val starredFiles: StateFlow<List<FileItem>> = _starredFiles.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val recentFiles: StateFlow<List<FileItem>> = _recentFiles.asStateFlow()

    private val _optimizationReport = MutableStateFlow<OptimizationReport?>(null)
    val optimizationReport: StateFlow<OptimizationReport?> = _optimizationReport.asStateFlow()

    // Text Editor state
    private val _editorFile = MutableStateFlow<FileItem?>(null)
    val editorFile: StateFlow<FileItem?> = _editorFile.asStateFlow()

    private val _editorContent = MutableStateFlow("")
    val editorContent: StateFlow<String> = _editorContent.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeSampleFilesIfEmpty()
            refreshCurrentDirectory()
            refreshStorageStats()
            observeDatabaseFlows()
        }
    }

    private fun observeDatabaseFlows() {
        viewModelScope.launch {
            repository.getTrashItems().collectLatest {
                _trashItems.value = it
            }
        }
        viewModelScope.launch {
            repository.getStarredFiles().collectLatest { starredEntities ->
                val items = starredEntities.mapNotNull { entity ->
                    val f = File(entity.path)
                    if (f.exists()) {
                        FileItem(
                            path = f.absolutePath,
                            name = f.name,
                            extension = f.extension,
                            size = if (f.isDirectory) 0L else f.length(),
                            lastModified = f.lastModified(),
                            isDirectory = f.isDirectory,
                            childCount = if (f.isDirectory) (f.listFiles()?.size ?: 0) else 0,
                            category = if (f.isDirectory) FileCategory.OTHER else FileCategory.fromExtension(f.extension),
                            isStarred = true
                        )
                    } else null
                }
                _starredFiles.value = items
            }
        }
        viewModelScope.launch {
            repository.getRecentFiles().collectLatest { recentEntities ->
                val items = recentEntities.mapNotNull { entity ->
                    val f = File(entity.path)
                    if (f.exists()) {
                        FileItem(
                            path = f.absolutePath,
                            name = f.name,
                            extension = f.extension,
                            size = if (f.isDirectory) 0L else f.length(),
                            lastModified = f.lastModified(),
                            isDirectory = f.isDirectory,
                            childCount = if (f.isDirectory) (f.listFiles()?.size ?: 0) else 0,
                            category = if (f.isDirectory) FileCategory.OTHER else FileCategory.fromExtension(f.extension)
                        )
                    } else null
                }
                _recentFiles.value = items
            }
        }
    }

    fun navigateTo(destination: ScreenDestination) {
        if (_currentScreen.value != destination) {
            screenStack.add(_currentScreen.value)
            _currentScreen.value = destination
            _selectedFiles.value = emptySet()
            if (destination is ScreenDestination.CategoryDetail) {
                loadCategoryFiles(destination.category)
            } else if (destination is ScreenDestination.StorageAnalyzer) {
                loadOptimizationReport()
            }
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.isNotEmpty()) {
            val previous = screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = previous
            _selectedFiles.value = emptySet()
            return true
        }
        return false
    }

    fun openDirectory(dir: File) {
        _currentDirectory.value = dir
        _searchQuery.value = ""
        _selectedFiles.value = emptySet()
        refreshCurrentDirectory()
        if (_currentScreen.value !is ScreenDestination.Explorer) {
            navigateTo(ScreenDestination.Explorer)
        }
    }

    fun navigateUpDirectory(): Boolean {
        val current = _currentDirectory.value
        val parent = current.parentFile
        if (parent != null && (current.absolutePath != repository.rootDir.absolutePath)) {
            _currentDirectory.value = parent
            refreshCurrentDirectory()
            return true
        }
        return false
    }

    fun refreshCurrentDirectory() {
        viewModelScope.launch {
            _isLoading.value = true
            val files = repository.getFiles(
                directory = _currentDirectory.value,
                sortOption = _sortOption.value,
                searchQuery = _searchQuery.value
            )
            _currentFiles.value = files
            _isLoading.value = false
        }
    }

    fun refreshStorageStats() {
        viewModelScope.launch {
            _storageStats.value = repository.calculateStorageStats()
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        refreshCurrentDirectory()
    }

    fun setSortOption(sort: SortOption) {
        _sortOption.value = sort
        refreshCurrentDirectory()
    }

    fun toggleViewMode() {
        _viewMode.value = if (_viewMode.value == ViewMode.LIST) ViewMode.GRID else ViewMode.LIST
    }

    fun toggleFileSelection(file: FileItem) {
        val current = _selectedFiles.value.toMutableSet()
        if (current.contains(file)) {
            current.remove(file)
        } else {
            current.add(file)
        }
        _selectedFiles.value = current
    }

    fun selectAllFiles() {
        _selectedFiles.value = _currentFiles.value.toSet()
    }

    fun clearSelection() {
        _selectedFiles.value = emptySet()
    }

    fun loadCategoryFiles(category: FileCategory) {
        viewModelScope.launch {
            _isLoading.value = true
            _categoryFiles.value = repository.getCategoryFiles(category)
            _isLoading.value = false
        }
    }

    fun loadOptimizationReport() {
        viewModelScope.launch {
            _isLoading.value = true
            _optimizationReport.value = repository.findOptimizationCandidates()
            _isLoading.value = false
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            val result = repository.createFolder(_currentDirectory.value, name)
            result.onSuccess {
                showMessage("Folder '${it.name}' created")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Error: ${it.message}")
            }
        }
    }

    fun createFile(name: String, content: String = "") {
        viewModelScope.launch {
            val result = repository.createFile(_currentDirectory.value, name, content)
            result.onSuccess {
                showMessage("File '${it.name}' created")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Error: ${it.message}")
            }
        }
    }

    fun renameFile(file: FileItem, newName: String) {
        viewModelScope.launch {
            val result = repository.rename(file.file, newName)
            result.onSuccess {
                showMessage("Renamed to '${it.name}'")
                refreshCurrentDirectory()
            }.onFailure {
                showMessage("Rename failed: ${it.message}")
            }
        }
    }

    fun duplicateFile(file: FileItem) {
        viewModelScope.launch {
            val result = repository.duplicate(file.file)
            result.onSuccess {
                showMessage("Duplicated as '${it.name}'")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Duplicate failed: ${it.message}")
            }
        }
    }

    fun deleteFileToTrash(file: FileItem) {
        viewModelScope.launch {
            val result = repository.moveToTrash(file.file)
            result.onSuccess {
                showMessage("Moved '${file.name}' to Trash")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Delete failed: ${it.message}")
            }
        }
    }

    fun deleteSelectedToTrash() {
        viewModelScope.launch {
            val count = _selectedFiles.value.size
            for (item in _selectedFiles.value) {
                repository.moveToTrash(item.file)
            }
            _selectedFiles.value = emptySet()
            showMessage("Moved $count items to Trash")
            refreshCurrentDirectory()
            refreshStorageStats()
        }
    }

    fun copySelected() {
        _clipboard.value = ClipboardBuffer(
            files = _selectedFiles.value.toList(),
            operation = ClipboardOperation.COPY
        )
        showMessage("Copied ${_selectedFiles.value.size} items to clipboard")
        _selectedFiles.value = emptySet()
    }

    fun cutSelected() {
        _clipboard.value = ClipboardBuffer(
            files = _selectedFiles.value.toList(),
            operation = ClipboardOperation.MOVE
        )
        showMessage("Cut ${_selectedFiles.value.size} items to clipboard")
        _selectedFiles.value = emptySet()
    }

    fun pasteClipboard() {
        val clip = _clipboard.value ?: return
        viewModelScope.launch {
            val targetDir = _currentDirectory.value
            for (item in clip.files) {
                if (clip.operation == ClipboardOperation.COPY) {
                    repository.copy(item.file, targetDir)
                } else {
                    repository.move(item.file, targetDir)
                }
            }
            showMessage("${if (clip.operation == ClipboardOperation.COPY) "Copied" else "Moved"} ${clip.files.size} items")
            _clipboard.value = null
            refreshCurrentDirectory()
            refreshStorageStats()
        }
    }

    fun clearClipboard() {
        _clipboard.value = null
    }

    fun zipSelectedFiles(zipName: String) {
        viewModelScope.launch {
            val selected = _selectedFiles.value.map { it.file }
            if (selected.isEmpty()) return@launch
            val finalName = if (zipName.endsWith(".zip", ignoreCase = true)) zipName else "$zipName.zip"
            val destZip = File(_currentDirectory.value, finalName)
            val result = repository.zipFiles(selected, destZip)
            result.onSuccess {
                showMessage("Compressed into '${it.name}'")
                _selectedFiles.value = emptySet()
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Zip failed: ${it.message}")
            }
        }
    }

    fun unzipFile(file: FileItem) {
        viewModelScope.launch {
            val targetFolder = File(file.file.parentFile, file.file.nameWithoutExtension)
            targetFolder.mkdirs()
            val result = repository.unzipArchive(file.file, targetFolder)
            result.onSuccess {
                showMessage("Extracted ${it.size} files into '${targetFolder.name}'")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Extraction failed: ${it.message}")
            }
        }
    }

    fun restoreTrashItem(item: TrashItemEntity) {
        viewModelScope.launch {
            val result = repository.restoreFromTrash(item)
            result.onSuccess {
                showMessage("Restored '${item.originalName}'")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Restore failed: ${it.message}")
            }
        }
    }

    fun deleteTrashPermanently(item: TrashItemEntity) {
        viewModelScope.launch {
            val result = repository.deletePermanently(File(item.trashPath))
            result.onSuccess {
                showMessage("Permanently deleted '${item.originalName}'")
                refreshStorageStats()
            }.onFailure {
                showMessage("Delete failed: ${it.message}")
            }
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            val result = repository.emptyTrash()
            result.onSuccess {
                showMessage("Recycle Bin emptied")
                refreshStorageStats()
                loadOptimizationReport()
            }.onFailure {
                showMessage("Error: ${it.message}")
            }
        }
    }

    fun toggleStar(file: FileItem) {
        viewModelScope.launch {
            repository.toggleStar(file)
            refreshCurrentDirectory()
        }
    }

    fun openFile(file: FileItem) {
        viewModelScope.launch {
            repository.recordRecentAccess(file.file)
            if (file.isDirectory) {
                openDirectory(file.file)
            } else if (file.isTextEditable) {
                _editorFile.value = file
                _editorContent.value = repository.readText(file.file)
                navigateTo(ScreenDestination.TextEditor(file))
            } else if (file.isImage) {
                navigateTo(ScreenDestination.ImageViewer(file))
            } else if (file.isArchive) {
                unzipFile(file)
            } else {
                // Generic open text preview
                _editorFile.value = file
                _editorContent.value = repository.readText(file.file)
                navigateTo(ScreenDestination.TextEditor(file))
            }
        }
    }

    fun saveEditorContent(newContent: String) {
        val file = _editorFile.value ?: return
        viewModelScope.launch {
            val res = repository.writeText(file.file, newContent)
            res.onSuccess {
                _editorContent.value = newContent
                showMessage("Saved changes to '${file.name}'")
                refreshCurrentDirectory()
                refreshStorageStats()
            }.onFailure {
                showMessage("Failed to save: ${it.message}")
            }
        }
    }

    fun updateEditorText(text: String) {
        _editorContent.value = text
    }

    fun showMessage(msg: String) {
        _userMessage.value = msg
    }

    fun clearMessage() {
        _userMessage.value = null
    }

    fun deleteEmptyFolder(folder: File) {
        viewModelScope.launch {
            folder.delete()
            showMessage("Deleted empty folder '${folder.name}'")
            loadOptimizationReport()
            refreshCurrentDirectory()
            refreshStorageStats()
        }
    }
}
